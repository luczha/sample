﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

using MyApp;
using MyApp.iOS;
using System.Threading;
[assembly: ExportRenderer(typeof(Page1), typeof(MyContentPageRenderer))]
namespace MyApp.iOS
{
    public class MyContentPageRenderer:PageRenderer
    {
        public MyContentPageRenderer()
        {

        }


        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);

            NSNotification notification = NSNotification.FromName("scrollToButtom",null);

            NSNotificationCenter.DefaultCenter.PostNotification(notification);

        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);
            
        }
    }
}