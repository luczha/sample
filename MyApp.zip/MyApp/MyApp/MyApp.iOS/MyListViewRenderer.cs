﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;


using ObjCRuntime;

using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

using MyApp;
using MyApp.iOS;

[assembly: ExportRenderer(typeof(MyListView), typeof(MyListViewRenderer))]
namespace MyApp.iOS
{
    public class MyListViewRenderer:ListViewRenderer,IUITableViewDelegate
    {

        bool isFirstLoad = true;

        public MyListViewRenderer()
        {
           
            
        }

        [Export("tableView:willDisplayCell:forRowAtIndexPath:")]
        public void WillDisplay(UITableView tableView,UITableViewCell cell,NSIndexPath indexPath)
        {
           if(isFirstLoad)
            {
               
                var element = Element as MyListView;
                
                if (element.ItemsSource is IList<string> items && items.Count > 0)
                {
                                   
                 if(indexPath.Row!=items.Count-1)
                    {
                        NSIndexPath nSIndexPath = NSIndexPath.FromItemSection(indexPath.Row + 1, 0);
                        tableView.ScrollToRow(nSIndexPath, UITableViewScrollPosition.Bottom, false);
                        
                    }
                 else
                    {
                        isFirstLoad = false;
                    }
                }
               
            }
        }


 
      


        protected override void OnElementChanged(ElementChangedEventArgs<ListView> e)
        {
            base.OnElementChanged(e);
           
            if(Control!=null)
            {
                Control.WeakDelegate = this;
            }
          

        }


    }
}